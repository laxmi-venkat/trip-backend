package com.excelr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.excelr.model.Headphones;
import com.excelr.model.Laptops;
import com.excelr.model.Mobiles;
import com.excelr.model.User;
import com.excelr.repo.UserRepository;
import com.excelr.service.ExcelRService;
import com.excelr.util.JwtFilter;
import com.excelr.util.JwtUtil;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class ExcelrController {
	
	@Autowired
	
	public ExcelRService excelRService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private JwtFilter jwtFilter;
	
	@PostMapping("/login")
	
	public ResponseEntity<Map<String,String>> login(@RequestBody Map<String,String> loginData){
		
		// read username and password from reactJs
		String username =loginData.get("username");
		String password = loginData.get("password");
		
		//compare react username with database
		Optional<User> user = userRepository.findByUsername(username);
		
		if(user.isPresent() && user.get().getPassword().equals(password)) {
			Map<String, String> response = new HashMap<>();
			String token = jwtUtil.generateToken(username);
			response.put("login", "success");
			response.put("token", token);
			 return ResponseEntity.ok(response);
		}else {
			Map<String, String> response1 = new HashMap<>();
			response1.put("login", "fail");
			 return ResponseEntity.ok(response1);
		}
	}
	
	@GetMapping("/user/laptops")
	public List<Laptops> getLaptops() {
		return excelRService.getLaptops();
	}
	
	@GetMapping("/user/mobiles")
	public List<Mobiles> getMobiles() {
		return excelRService.getMobiles();
	}
	@GetMapping("/user/headphones")
	public List<Headphones> getHeadphones(){
		return excelRService.getHeadphones();
	}
	
	@GetMapping("/user/laptops/{pid}")
	public Optional<Laptops> getSingleLaptop(@PathVariable Long pid){
		return excelRService.getLaptopById(pid);
	}
	@GetMapping("/user/mobiles/{pid}")
	public Optional<Mobiles> getSingleMobile(@PathVariable Long pid){
		return excelRService.getMobilesById(pid);
	}
	@GetMapping("/user/headphones/{pid}")
	public Optional<Headphones> getSingleHeadphone(@PathVariable Long pid){
		return excelRService.getHeadphonesById(pid);
	}
	
	@PostMapping("/admin/upload/laptops")
	public ResponseEntity<?> uploadLaptops(@RequestParam String pname,
								@RequestParam int pqty,
								@RequestParam int pcost,
								@RequestParam MultipartFile file ) {
		
		if(pname == null || pname.isEmpty() || pcost<=0|| file == null || file.isEmpty()||pqty<=0) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Input parameters");
		}
		else {
			Laptops savedLaptop = null;
			try {
			 savedLaptop = excelRService.saveLaptop(pname, pcost, pqty, file);
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			return ResponseEntity.ok(savedLaptop);
		}
	}
	
	@PostMapping("/admin/upload/headphones")
	public String uploadHeadphones() {
		return "admin will upload headphones soon";
	}
	
	@PostMapping("/admin/upload/mobiles")
	public String uploadMobiles() {
		return "admin will upload mobiles soon";
	}
	
	@PostMapping("/admin/register")
	public String register(){
		return "Register soon...";
	}
}