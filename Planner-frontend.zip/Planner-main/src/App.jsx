import React from 'react';
import './App.css'; // Optional for global styles
import MasterController from './MasterController';

function App() {
  return (
    <div className="App">
      <MasterController />
    </div>
  );
}

export default App;
